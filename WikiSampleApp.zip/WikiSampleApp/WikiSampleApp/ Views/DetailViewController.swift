//
//  DetailViewController.swift
//  WikiSampleApp
//
//  Created by VenkatPeetla on 23/06/18.
//  Copyright © 2018 VenkatPeetla. All rights reserved.
//

import UIKit
import WebKit
import Foundation

class DetailViewController: UIViewController {
    @IBOutlet weak var detailwebView: UIView!
    var activityIndicator: UIActivityIndicatorView!

    var wKWebView: WKWebView!
    var getDetailsUrl:String!
    override func viewDidLoad() {
        super.viewDidLoad()
        let urlStr:String  = getDetailsUrl
        let url = URL.init(string: urlStr)
        let request = URLRequest.init(url:url!, cachePolicy: URLRequest.CachePolicy.useProtocolCachePolicy, timeoutInterval: 5)
        
        let uniqueProcessPool = WKProcessPool()
        
        let configA = WKWebViewConfiguration()
        configA.processPool = uniqueProcessPool
        wKWebView =  WKWebView.init(frame: createWKWebViewFrame(size: view.frame.size), configuration: configA)

//        wKWebView = WKWebView(frame: createWKWebViewFrame(size: view.frame.size))
        detailwebView.addSubview(wKWebView)
        wKWebView.navigationDelegate = self
        wKWebView.uiDelegate = self
        
        
        if UserDefaults.standard.string(forKey: "Key") != nil {
            let htmlString  = UserDefaults.standard.string(forKey: "Key")!
            if htmlString.count > 0 && htmlString != nil{
                wKWebView.loadHTMLString(htmlString, baseURL: nil)
                UserDefaults.standard.removeObject(forKey: "Key")
            }
        }else{
            wKWebView.load(request)
        }
        
        
        activityIndicator = UIActivityIndicatorView()
        activityIndicator.frame = CGRect.init(x: 0, y: 0, width: 100, height: 100)
        activityIndicator.center = self.view.center
        activityIndicator.hidesWhenStopped = true
        activityIndicator.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.gray
        
        detailwebView.addSubview(activityIndicator)

        wKWebView.translatesAutoresizingMaskIntoConstraints = false
        self.detailwebView.addConstraints([
            NSLayoutConstraint(item: wKWebView, attribute: .width, relatedBy: .equal, toItem: self.detailwebView, attribute: .width, multiplier: 1.0, constant: 0),
            NSLayoutConstraint(item: wKWebView, attribute: .height, relatedBy: .equal, toItem: self.detailwebView, attribute: .height, multiplier: 1.0, constant: 0),
            NSLayoutConstraint(item: wKWebView, attribute: .centerX, relatedBy: .equal, toItem: self.detailwebView, attribute: .centerX, multiplier: 1.0, constant: 0),
            NSLayoutConstraint(item: wKWebView, attribute: .centerY, relatedBy: .equal, toItem: self.detailwebView, attribute: .centerY, multiplier: 1.0, constant: 0),
            ])
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func showActivityIndicator(show: Bool) {
        if show {
            activityIndicator.startAnimating()
        } else {
            activityIndicator.stopAnimating()
        }
    }

    
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        showActivityIndicator(show: false)

    }
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        showActivityIndicator(show: true)

    }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        showActivityIndicator(show: false)
        
        webView.evaluateJavaScript("document.documentElement.outerHTML.toString()",
                                   completionHandler: { (html: Any?, error: Error?) in
//                                    UserDefaults.standard.set(html, forKey: "Key")
                                    print(html as! String)
        })
    }
    func webView(_ webView: WKWebView, decidePolicyFor navigationResponse: WKNavigationResponse, decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
        let headers = (navigationResponse.response as! HTTPURLResponse)
        //do something with headers
        decisionHandler(.allow)
    }
}
extension DetailViewController {
    fileprivate func createWKWebViewFrame(size: CGSize) -> CGRect {
        let navigationHeight: CGFloat = 60
        let toolbarHeight: CGFloat = 0
        let height = size.height - navigationHeight - toolbarHeight
        return CGRect(x: 0, y: 0, width: size.width, height: height)
    }
}

extension DetailViewController: WKNavigationDelegate {
//    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
//        // show indicator
//    }
//
//    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
//        // dismiss indicator
//
//        // if url is not valid {
//        //    decisionHandler(.cancel)
//        // }
//        decisionHandler(.allow)
//    }
//
//    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
//        // dismiss indicator
//
//        goBackButton.isEnabled = webView.canGoBack
//        goForwardButton.isEnabled = webView.canGoForward
//        navigationItem.title = webView.title
//    }
//
//    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
//        // show error dialog
//    }
}

extension DetailViewController: WKUIDelegate {
    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if navigationAction.targetFrame == nil {
            webView.load(navigationAction.request)
        }
        return nil
    }
}
