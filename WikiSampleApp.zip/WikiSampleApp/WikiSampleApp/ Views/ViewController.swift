//
//  ViewController.swift
//  WikiSampleApp
//
//  Created by VenkatPeetla on 22/06/18.
//  Copyright © 2018 VenkatPeetla. All rights reserved.
//

import UIKit
import CoreData

struct itemlistForSearch {
    var firstName: String
    var lastName: String
}

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource,UISearchBarDelegate {
    @objc var fetchedResultsController: NSFetchedResultsController<NSFetchRequestResult>!
    var offlineData = [itemlistForSearch]()
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var suggestLbl: UILabel!
    var itemList: [ItemList] = []

    let identifier: String = "tableCell"
    let language = WikipediaLanguage("en")
    let wikipedia = Wikipedia.shared
    var searchActive : Bool = false

    var finalResults: WikipediaSearchResults?
    let appDelegate = UIApplication.shared.delegate as? AppDelegate
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        

        
        let managedContext = appDelegate?.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "ItemList")
        do {
            itemList = (try managedContext?.fetch(fetchRequest))! as! [ItemList]
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
        print("Could  fetch Count . \(itemList.count)")

        print(itemList.count)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        navigationController?.navigationBar.barTintColor = UIColor.init(red: 255/255, green: 84/255, blue: 84/255, alpha: 1)
        self.title = "Wiki App"
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedStringKey.font: UIFont(name: "HelveticaNeue-Bold", size: 20)!]
        let nav = self.navigationController?.navigationBar
        nav?.barStyle = UIBarStyle.black
        nav?.tintColor = UIColor.white
        nav?.titleTextAttributes = [NSAttributedStringKey.foregroundColor : UIColor.white]
        self.tableView.isHidden = true
        self.suggestLbl.isHidden = false

    }

    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        searchActive = true;
    }
    
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        searchActive = false;
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchActive = false;
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchActive = false;
        searchBar.resignFirstResponder()

    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        guard let status = Network.reachability?.isReachable else {
            return
            
        }
        if !status {
           self.offlineData =  self.searchOffLineData(searchText)
            self.tableView.reloadData()
        }else{
            let _ = wikipedia.requestOptimizedSearchResults(language: language, term: searchText) { (searchResults, error) in
                self.finalResults = searchResults
                for searchitem in (self.finalResults?.results)!{
                    self.save(results: searchitem)
                }
                self.tableView.reloadData()
            }
        }
        
        if searchText.count > 0 {
            self.tableView.isHidden = false
            self.suggestLbl.isHidden = true
            
        }else{
            self.tableView.isHidden = true
            self.suggestLbl.isHidden = false
        }

    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    // MARK: UITableView DataSource
     func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: identifier) as? TableCell {
            
            
            if (Network.reachability?.isReachable)! {
                cell.nameLabel.text = self.finalResults?.results[indexPath.row].displayTitle
                cell.prepTimeLabel.text = self.finalResults?.results[indexPath.row].description
                cell.prepTimeLabel.sizeToFit()
                if self.finalResults != nil{
                    
                }
                DispatchQueue.global().async {
                    let data = try? Data(contentsOf: (self.finalResults?.results[indexPath.row].imageURL != nil ? self.finalResults?.results[indexPath.row].imageURL : URL.init(string: "Dummy"))!) //make sure your image in this url does exist, otherwise unwrap in a if let check / try-catch
                    DispatchQueue.main.async {
                        if data != nil{
                            cell.thumbnailImageView.image = UIImage(data: data != nil ? data! : Data.init())
                        }else{
                            cell.thumbnailImageView.image = UIImage.init(named: "Placeholder_imge")
                        }
                    }
                }

            }else{
                cell.nameLabel.text = self.offlineData[indexPath.row].firstName
                cell.prepTimeLabel.text = self.offlineData[indexPath.row].lastName
                cell.prepTimeLabel.sizeToFit()

            }
            
            

            return cell
        }
        return UITableViewCell()
    }
    
     func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if (Network.reachability?.isReachable)! {
            if self.finalResults != nil {
                return (self.finalResults?.results.count)!
            }else{
                return 0
            }
        }
        else{
           return offlineData.count
        }
    }
    
    
    
    // MARK: Segue Method
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (Network.reachability?.isReachable)! {
            if segue.identifier == "recipeDetail",
                let indexPath = self.tableView?.indexPathForSelectedRow,
                let destinationViewController: DetailViewController = segue.destination as? DetailViewController {
                let  nameOfString:String = (self.finalResults?.results[indexPath.row].displayTitle)!
                let manuplateString = String(nameOfString.map {
                    $0 == " " ? "_" : $0
                })
                destinationViewController.getDetailsUrl = "https://\(language.code).wikipedia.org/wiki/\(manuplateString)"
            }
        }else{
            let alertController = UIAlertController(title: "User Message", message: "Currently you are in OFFLINE please come to ONLINE and then clik for details", preferredStyle: .alert)
            let action = UIAlertAction(title: "OK", style: .cancel) { (action:UIAlertAction) in
            }
            alertController.addAction(action)
            self.present(alertController, animated: true, completion: nil)

        }
    }
    
    func fetchRequest(_ searshStr:String) -> NSFetchRequest<NSFetchRequestResult> {
        let fetchRequest = NSFetchRequest<ItemList>(entityName: "ItemList")
       fetchRequest.predicate =  NSPredicate(format: "name contains[c] '\(searshStr)'")
        fetchRequest.sortDescriptors = [NSSortDescriptor(key: "name", ascending: false)]
        return fetchRequest as! NSFetchRequest<NSFetchRequestResult>
    }
    
    func searchOffLineData(_ searchText: String) -> [itemlistForSearch] {

        var filtervalues = [itemlistForSearch]()
        let managedObjectContext = appDelegate?.persistentContainer.viewContext
        fetchedResultsController = NSFetchedResultsController(fetchRequest: self.fetchRequest(searchText), managedObjectContext: managedObjectContext!, sectionNameKeyPath: nil, cacheName: nil)
        fetchedResultsController.delegate = self as? NSFetchedResultsControllerDelegate
        do {
            try fetchedResultsController.performFetch()
        } catch {}

        for eachValue in fetchedResultsController.fetchedObjects! {
            let getvalue = eachValue as! ItemList
            let onevalue = itemlistForSearch(firstName: getvalue.name!, lastName: getvalue.subDetails!)
            filtervalues.append(onevalue)
        }
        return filtervalues
       
    }
    
    func save(results: WikipediaArticlePreview) {
        let managedContext = appDelegate?.persistentContainer.viewContext

        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "ItemList")
        let predicate = NSPredicate(format: "name == %@", results.displayTitle)
        request.predicate = predicate
        request.fetchLimit = 1
        do{
            let count = try managedContext?.count(for: request)
            if(count == 0){
                // no matching object
                let entity = NSEntityDescription.entity(forEntityName: "ItemList",
                                                        in: managedContext!)!
                
                let Item = NSManagedObject(entity: entity,
                                           insertInto: managedContext)
                
                Item.setValue(results.displayTitle, forKey: "name")
                Item.setValue(results.description, forKey:"subDetails")
                Item.setValue(results.imageURL?.dataRepresentation, forKey: "image")
                
                do {
                    try managedContext?.save()
                    itemList.append(Item as! ItemList)
                } catch let error as NSError {
                    print("Could not save. \(error), \(error.userInfo)")
                }
            }
            else{
            }
        }
        catch let error as NSError {
            print("Could not fetch \(error), \(error.userInfo)")
        }
        
        
       
    }
    
   
}

