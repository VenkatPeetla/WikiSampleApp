//
//  ItemList+CoreDataClass.swift
//  WikiSampleApp
//
//  Created by VenkatPeetla on 24/06/18.
//  Copyright © 2018 VenkatPeetla. All rights reserved.
//
//

import Foundation
import CoreData

//@objc(ItemList)
public class ItemList: NSManagedObject {

}
