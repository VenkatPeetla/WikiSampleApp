//
//  ItemList+CoreDataProperties.swift
//  WikiSampleApp
//
//  Created by VenkatPeetla on 24/06/18.
//  Copyright © 2018 VenkatPeetla. All rights reserved.
//
//

import Foundation
import CoreData
extension ItemList {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<ItemList> {
        return NSFetchRequest<ItemList>(entityName: "ItemList")
    }

    @NSManaged public var name: String?
    @NSManaged public var subDetails: String?
    @NSManaged public var image: NSData?

}
