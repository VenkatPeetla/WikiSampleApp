import Foundation

extension String {
    
    public func wikipediaURLEncodedString(replaceSpacesWithUnderscores: Bool = true) -> String {
        var string = self
        
        // Wikipedia URL encoding specialties:
        // - Spaces can be replaced with underscores
        // - Colons and parentheses are allowed
        
        if replaceSpacesWithUnderscores {
            string = string.replacingOccurrences(of: " ", with: "_")
        }
        
        var characterSet = NSMutableCharacterSet.urlQueryAllowed
        
        // Comma must not be encoded, otherwise the Most Read articles API call will not work on ru.wikipedia.org
        let delimitersToEncode = ":#[]@!$?&'()*+="
        characterSet.remove(charactersIn: delimitersToEncode)
        
        return string.addingPercentEncoding(withAllowedCharacters: characterSet as CharacterSet) ?? string
    }

}
