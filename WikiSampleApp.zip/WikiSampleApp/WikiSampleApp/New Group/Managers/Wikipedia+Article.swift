import Foundation

extension Wikipedia {
    
    public func requestArticle(language: WikipediaLanguage,
                               title: String,
                               imageWidth: Int,
                               completion: @escaping (WikipediaArticle?, WikipediaError?)->())
        -> URLSessionDataTask? {
            
        
        if let cachedArticle = self.articleCache.get(language: language, title: title) {
            DispatchQueue.main.async {
                completion(cachedArticle, nil)
            }
            return nil
        }
            
        let parameters: [String:String] = [
            "action": "mobileview",
            "format": "json",
            "page": title,
            "mobileformat": "1",
            "prop": "id|text|sections|languagecount|displaytitle|description|image|thumb",
            "sections": "all",
            "sectionprop": "toclevel|level|line|anchor",
            "thumbwidth" : "\(imageWidth)",
            "redirect": "yes",
            "maxage": "\(self.maxAgeInSeconds)",
            "smaxage": "\(self.maxAgeInSeconds)",
            "uselang": language.variant ?? language.code,
            ]
        
        guard let request = Wikipedia.buildURLRequest(language: language, parameters: parameters) else {
                DispatchQueue.main.async {
                    completion(nil, .other(nil))
                }
                return nil
        }
        
        return WikipediaNetworking.shared.loadJSON(urlRequest: request) { jsonDictionary, error in
            
            guard error == nil else {
                DispatchQueue.main.async {
                    completion (nil, error)
                }
                return
            }
            
            guard let jsonDictionary = jsonDictionary  else {
                DispatchQueue.main.async {
                    completion (nil, .decodingError)
                }
                return
            }
            
            if let apiError = jsonDictionary["error"] as? JSONDictionary,
                let apiErrorInfo = apiError["info"] as? String {
                
                var wikipediaError: WikipediaError
                
                if let apiErrorCode = apiError["code"] as? String,
                       apiErrorCode == "missingtitle" {
                    
                    wikipediaError = .notFound
                } else {
                    wikipediaError = .apiError(apiErrorInfo)
                }
                
                DispatchQueue.main.async {
                    completion (nil, wikipediaError)
                }
                return
            }
            
            let article = WikipediaArticle(jsonDictionary: jsonDictionary, language: language, title: title)
            
            if let article = article {
                self.articleCache.add(article)
            }
            
            DispatchQueue.main.async {
                completion(article, error)
            }
        }
    }
}
