import Foundation

extension Wikipedia {
    
    public func requestAvailableLanguages(for article: WikipediaArticle,
                                          completion: @escaping (WikipediaArticle, WikipediaError?)->())
        -> URLSessionDataTask? {
            
        guard article.languageLinks == nil, // has not been populated previously
              article.areOtherLanguagesAvailable // other languages are available
              else {
                DispatchQueue.main.async {
                    completion(article, nil)
                }
                return nil
        }
            
        let parameters: [String:String] = [
            "action": "parse",
            "format": "json",
            "formatversion": "2",
            "page" : article.title,
            "prop": "langlinks",
            "maxage": "\(self.maxAgeInSeconds)",
            "smaxage": "\(self.maxAgeInSeconds)",
            "uselang": WikipediaLanguage.systemLanguage.variant ?? WikipediaLanguage.systemLanguage.code,
            ]
        
        guard let request = Wikipedia.buildURLRequest(language: article.language, parameters: parameters)
            else {
                DispatchQueue.main.async {
                    completion(article, .other(nil))
                }
                return nil
        }
        
        return WikipediaNetworking.shared.loadJSON(urlRequest: request) { jsonDictionary, error in
            
            guard error == nil else {
                // (also occurs when the request was cancelled programmatically)
                DispatchQueue.main.async {
                    completion (article, error)
                }
                return
            }
            
            guard let jsonDictionary = jsonDictionary  else {
                DispatchQueue.main.async {
                    completion (article, .decodingError)
                }
                return
            }
            
            guard let parse = jsonDictionary["parse"] as? JSONDictionary,
                let langlinks = parse["langlinks"] as? [JSONDictionary]
                else {
                    DispatchQueue.main.async {
                        completion (article, .decodingError)
                    }
                    return
            }
            let languages = langlinks.flatMap(WikipediaArticleLanguageLink.init)
            article.languageLinks = languages
            DispatchQueue.main.async {
                completion(article, error)
            }
        }
    }
}
