import Foundation

public class WikipediaArticle {
    
    public var language: WikipediaLanguage
   
    public var title: String
    public var displayTitle: String
    
    public var rawText = ""
    public lazy var displayText: String = {
        return Wikipedia.sharedFormattingDelegate?.format(context: .article, rawText: self.rawText, title: self.title, language: self.language, isHTML: true) ?? self.rawText
    }()
    
    public var toc = [WikipediaTOCItem]()

    public var coordinate: (latitude: Double, longitude: Double)?

    public var imageURL: URL?
    public var imageID: String?
    
    public lazy var url: URL? = {
        let escapedTitle = self.title.wikipediaURLEncodedString()
        let urlString = "https://" + self.language.code + ".wikipedia.org/wiki/" + escapedTitle
        let url = URL(string: urlString)
        return url
    }()
    
    public lazy var editURL: URL? = {
        let escapedTitle = self.title.wikipediaURLEncodedString()
        let editURLString = "https://" + self.language.code + ".m.wikipedia.org/w/index.php?action=edit&title=" + escapedTitle
        let editURL = URL(string: editURLString)
        return editURL
    }()
    
    public init(language: WikipediaLanguage, title: String, displayTitle: String) {
        self.language = language
        self.title = title.replacingOccurrences(of: "_", with: " ")
        
        
        var formattedTitle = displayTitle.replacingOccurrences(of: "_", with: " ")
        formattedTitle = (Wikipedia.sharedFormattingDelegate?.format(context: .articleTitle,
                                                                   rawText: formattedTitle,
                                                                   title: title,
                                                                   language: language,
                                                                   isHTML: true)) ?? formattedTitle
        self.displayTitle = formattedTitle
    }
    
    public var areOtherLanguagesAvailable = false
    public var languageCount = 0
    // will only be populated with extra API call; see Wikipedia+Languages.swift
    public var languageLinks: [WikipediaArticleLanguageLink]?
}


extension WikipediaArticle {
    convenience init?(jsonDictionary dict: JSONDictionary, language: WikipediaLanguage, title: String) {
        
        guard let mobileview = dict["mobileview"] as? JSONDictionary,
              let sections = mobileview["sections"] as? [JSONDictionary]
        else {
                return nil
        }
        
        var text = ""
        var toc = [WikipediaTOCItem]()
        
        for section in sections {
            if let sectionText = section["text"] as? String {
                text += sectionText
                // The first section (intro) does not have an anchor
                if let sectionAnchor = section["anchor"] as? String {
                    var sectionTitle = (section["line"] as? String ?? "")
                    sectionTitle = (Wikipedia.sharedFormattingDelegate?.format(context: .tableOfContentsItem,
                                                                             rawText: sectionTitle,
                                                                             title: title,
                                                                             language: language,
                                                                             isHTML: true)) ?? sectionTitle
                    let sectionTocLevel = section["toclevel"] as? Int ?? 0
                    toc.append(WikipediaTOCItem(title: sectionTitle, anchor: sectionAnchor, tocLevel: sectionTocLevel))
                }
            }
        }
        
        
        var title = title
        if let redirectedTitle = mobileview["redirected"] as? String {
            title = redirectedTitle
            if let range = redirectedTitle.range(of: "#") {
                // A redirect may contain a hash (Like Article_Title#Scroll_Target
                // TODO: Ideally, this hash would be passed back somehow 
                //       so that the scrolling target info is not just discarded.
                let hashRange = Range(uncheckedBounds: (lower: range.lowerBound, upper: redirectedTitle.endIndex))
                title.removeSubrange(hashRange)
            }
        }
        
        let rawDisplayTitle = (mobileview["displaytitle"] as? String) ?? title
        
        self.init(language: language, title: title, displayTitle: rawDisplayTitle)
        
        self.rawText = text
        self.toc = toc
        
        
        if let imageProperties = mobileview["image"] as? JSONDictionary,
            let imageID = imageProperties["file"] as? String {
            
            self.imageID = imageID
        }
        
        if let thumbProperties = mobileview["thumb"] as? JSONDictionary,
            let imageURLString = thumbProperties["url"] as? String,
            var imageURL = URL(string: imageURLString) {
            if var urlComponents = URLComponents(url: imageURL, resolvingAgainstBaseURL: false),
                urlComponents.scheme == nil {
                urlComponents.scheme = "https"
                imageURL = urlComponents.url ?? imageURL
            }
            self.imageURL = imageURL
        }
        
        if let languageCount = mobileview["languagecount"] as? Int {
            self.languageCount = languageCount
        }
        self.areOtherLanguagesAvailable = languageCount > 0
    }
}
