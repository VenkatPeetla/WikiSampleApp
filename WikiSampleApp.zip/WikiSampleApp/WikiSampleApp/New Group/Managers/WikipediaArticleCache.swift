
import Foundation

class WikipediaArticleCache {
    
    let cache = NSCache<AnyObject,WikipediaArticle>()
    
    func add(_ article: WikipediaArticle) {
        let cacheKey = self.cacheKey(language: article.language, title: article.title)
        self.cache.setObject(article, forKey: cacheKey)
    }
    
    func get(language: WikipediaLanguage, title: String) -> WikipediaArticle? {
        let cacheKey = self.cacheKey(language: language, title: title)
        let cachedSearchResult = self.cache.object(forKey: cacheKey)
        return cachedSearchResult
    }
    
    func cacheKey(language: WikipediaLanguage, title: String) -> AnyObject {
        let languageKey = language.variant ?? language.code
        let cacheKey = "\(languageKey)/\(title)"
        return cacheKey as AnyObject
    }
}
