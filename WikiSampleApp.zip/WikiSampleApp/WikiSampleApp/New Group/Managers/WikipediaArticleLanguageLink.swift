import Foundation

public struct WikipediaArticleLanguageLink {
    
    public let language: WikipediaLanguage
    public let title: String
    public let url: URL
    
    public init(language: WikipediaLanguage, title: String, url: URL) {
        self.language = language
        self.title = Wikipedia.sharedFormattingDelegate?.format(context: .articleTitle, rawText: title, title: title, language: language, isHTML: false) ?? title
        self.url = url
    }
}

extension WikipediaArticleLanguageLink {
    init?(jsonDictionary dict: JSONDictionary) {
        guard let languageCode = dict["lang"] as? String,
            let localizedName = dict["langname"] as? String,
            let autonym = dict["autonym"] as? String,
            let title = dict["title"] as? String, // TODO: Can we also get the display title here?
            let urlString = dict["url"] as? String,
            let url = URL(string: urlString)
        else { return nil }
        
        if !WikipediaLanguage.isBlacklisted(languageCode: languageCode) {
            let language = WikipediaLanguage(code: languageCode, localizedName: localizedName, autonym: autonym)
            self.init(language: language, title: title, url: url)
        } else {
            return nil
        }
    }
}
