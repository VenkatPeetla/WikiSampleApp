import Foundation

public protocol WikipediaBlacklistDelegate: class {
    func isBlacklistedForRecommendations(title: String, language: WikipediaLanguage) -> Bool
    func containsBlacklistedWords(text: String, language: WikipediaLanguage) -> Bool
}
