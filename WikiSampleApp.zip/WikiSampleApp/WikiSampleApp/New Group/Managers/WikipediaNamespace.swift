import Foundation

public enum WikipediaNamespace: Int {
    case media = -2
    case special = -1
    case main = 0
    case talk = 1
    case user = 2
    case userTalk = 3
    case project = 4
    case projectTalk = 5
    case file = 6
    case fileTalk = 7
    case mediaWiki = 8
    case mediaWikiTalk  = 9
    case template = 10
    case templateTalk = 11
    case help = 12
    case helpTalk = 13
    case category = 14
    case categoryTalk = 15
}
