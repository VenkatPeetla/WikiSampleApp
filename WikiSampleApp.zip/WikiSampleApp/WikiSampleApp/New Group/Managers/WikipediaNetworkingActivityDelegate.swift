import Foundation

public protocol WikipediaNetworkingActivityDelegate: class {
    func start()
    func stop()
}
