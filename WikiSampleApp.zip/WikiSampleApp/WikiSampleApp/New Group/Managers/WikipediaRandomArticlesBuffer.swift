import Foundation

class WikipediaRandomArticlesBuffer {
    
    static var shared: WikipediaRandomArticlesBuffer = {
        return WikipediaRandomArticlesBuffer()
    }()
 
    var articlePreviews = [WikipediaArticlePreview]()
    var language = WikipediaLanguage("en")
    
    func nextArticlePreview() -> WikipediaArticlePreview? {
        let a = articlePreviews.first
        self.articlePreviews = Array(self.articlePreviews.dropFirst())
        return a
    }
}
