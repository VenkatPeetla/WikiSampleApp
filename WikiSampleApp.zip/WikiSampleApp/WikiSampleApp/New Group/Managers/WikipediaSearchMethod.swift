public enum WikipediaSearchMethod: String {
    case fullText = "fullText"
    case prefix = "prefix"
}
