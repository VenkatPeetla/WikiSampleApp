public class WikipediaSearchResults {
    
    public var searchMethod = WikipediaSearchMethod.prefix
    
    public var term: String
    public var language: WikipediaLanguage
    public var offset = 0
    public var canLoadMore = true
    
    public var suggestions = [String]()
    
    public var results = [WikipediaArticlePreview]()
    
    public var hasResults: Bool {
        get {
            return self.results.count > 0 ? true : false
        }
    }
    
    public init(language: WikipediaLanguage, term: String) {
        self.language = language
        self.term = term
    }
}

