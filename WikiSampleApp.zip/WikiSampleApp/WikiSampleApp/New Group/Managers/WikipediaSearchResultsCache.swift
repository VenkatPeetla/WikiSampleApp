import Foundation

class WikipediaSearchResultsCache {
    
    let cache = NSCache<AnyObject,WikipediaSearchResults>()
    
    
    func add(_ searchResults: WikipediaSearchResults) {
        let cacheKey = self.cacheKey(method: searchResults.searchMethod, language: searchResults.language, term: searchResults.term)
        self.cache.setObject(searchResults, forKey: cacheKey as AnyObject)
    }
    
    func get(method: WikipediaSearchMethod, language: WikipediaLanguage, term: String) -> WikipediaSearchResults? {
        let cacheKey = self.cacheKey(method: method, language: language, term: term)
        let cachedSearchResult = self.cache.object(forKey: cacheKey as AnyObject)
        return cachedSearchResult
    }
    
    func cacheKey(method: WikipediaSearchMethod, language: WikipediaLanguage, term: String) -> String {
        let languageKey = language.variant ?? language.code
        let cacheKey = "\(method.rawValue)/\(languageKey)/\(term)"
        return cacheKey
    }
    
}

