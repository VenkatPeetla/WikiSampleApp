import Foundation

public struct WikipediaTOCItem {
    public let title: String
    public let anchor: String
    public let tocLevel: Int
    
    public init(title: String, anchor: String, tocLevel: Int) {
        self.title = title
        self.anchor = anchor
        self.tocLevel = tocLevel
    }
}
