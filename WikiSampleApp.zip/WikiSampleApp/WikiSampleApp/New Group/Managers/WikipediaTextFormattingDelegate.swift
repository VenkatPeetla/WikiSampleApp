import Foundation

public enum WikipediaTextFormattingDelegateContext {
    case article
    case articleTitle
    case articleDescription
    case articlePreview
    case tableOfContentsItem
}

public protocol WikipediaTextFormattingDelegate: class {
    
    // The article title and language are passed to make more informed decisions
    // on the formatting of rawText
    func format(context: WikipediaTextFormattingDelegateContext, rawText: String, title: String?, language: WikipediaLanguage, isHTML: Bool) -> String
}
